import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  ChevronRight,
  Clock3,
  Cpu,
  Dice5,
  Dices,
  Flame,
  MemoryStick,
  Mic,
  MicOff,
  Power,
  Quote,
  Rocket,
  Send,
  ShieldOff,
  Smile,
  Sparkles,
  Sun,
  Terminal,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import AICore, { type CoreState } from "./components/AICore";
import DeployConsole from "./components/DeployConsole";
import RazeOverlay, { RAZE_LOGS, type RazePhase } from "./components/RazeOverlay";
import { INITIAL_GREETING, respond } from "./ai/brain";
import { sfx, speak, stopSpeak } from "./ai/audio";

/* ------------------------------- Typen ------------------------------- */

interface Message {
  id: number;
  role: "user" | "ai" | "system";
  text: string;
  time: string;
}

const now = () =>
  new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });

const RAZE_CMD = /\braze\b/i;
const RAZE_OFF = /^(stopp!?|stop!?|raze aus!?|raze ende!?|beende raze|raze beenden|deaktiviere raze|raze deaktivieren|zurück zu normal|normalmodus)[.! ]*$/i;

const BOOT_LINES = [
  "NEXA KERNEL v4.2.1 — cold boot",
  "> Lade neuronale Matrix ............. OK",
  "> Kalibriere Sprachmodul [de-DE] .... OK",
  "> Wissensbank: 2,4 PB ............... SYNC",
  "> Humor-Subroutine .................. GELADEN",
  "> Etikette-Modul .................... AKTIV",
  "> RAZE-Protokoll .................... BEREIT",
  "> Biometrische Signatur ............. KOMMANDANT ERKANNT",
];

const CHIPS = [
  { label: "Uhrzeit", icon: Clock3, cmd: "Wie spät ist es?" },
  { label: "Witz", icon: Smile, cmd: "Erzähl mir einen Witz" },
  { label: "Rechne 18 × 7", icon: Cpu, cmd: "Rechne 18 * 7" },
  { label: "Wetter", icon: Sun, cmd: "Wie ist das Wetter?" },
  { label: "Motivation", icon: Zap, cmd: "Motivier mich" },
  { label: "Zufallsfakt", icon: Sparkles, cmd: "Zufallsfakt" },
  { label: "Würfeln", icon: Dices, cmd: "Würfel" },
  { label: "Orakel", icon: Quote, cmd: "Orakel: Soll ich heute etwas Großes wagen?" },
  { label: "Hilfe", icon: Terminal, cmd: "Was kannst du alles?" },
];

/* --------------------------- Typewriter --------------------------- */

function TypeText({
  text,
  active,
  onTick,
  onDone,
}: {
  text: string;
  active: boolean;
  onTick: () => void;
  onDone: () => void;
}) {
  const [n, setN] = useState(0);
  const doneRef = useRef(false);

  useEffect(() => {
    if (!active) {
      setN(text.length);
      return;
    }
    if (n >= text.length) {
      if (!doneRef.current) {
        doneRef.current = true;
        onDone();
      }
      return;
    }
    const step = text.length > 260 ? 4 : text.length > 120 ? 2 : 1;
    const id = setTimeout(() => {
      setN((v) => Math.min(v + step, text.length));
      onTick();
    }, 17);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [n, active, text]);

  return (
    <span className="whitespace-pre-wrap">
      {text.slice(0, n)}
      {active && n < text.length && <span className="anim-caret ml-0.5 inline-block h-[1em] w-[2px] translate-y-[2px] bg-[var(--accent)]" />}
    </span>
  );
}

/* --------------------------- Equalizer --------------------------- */

function Equalizer({ active, bars = 7 }: { active: boolean; bars?: number }) {
  return (
    <div className="flex h-5 items-center gap-[3px]">
      {Array.from({ length: bars }).map((_, i) => (
        <span
          key={i}
          className={`eq-bar block h-5 w-[3px] rounded-full ${active ? "bg-[var(--accent)]" : "bg-white/15"}`}
          style={{
            animationDuration: `${0.5 + (i % 4) * 0.13}s`,
            animationDelay: `${i * 0.07}s`,
            animationPlayState: active ? "running" : "paused",
            transform: active ? undefined : "scaleY(0.2)",
          }}
        />
      ))}
    </div>
  );
}

/* ------------------------------ Haupt-App ------------------------------ */

export default function App() {
  const [bootPhase, setBootPhase] = useState<"locked" | "booting" | "online">("locked");
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [typingId, setTypingId] = useState<number | null>(null);
  const [voiceOn, setVoiceOn] = useState(true);
  const [listening, setListening] = useState(false);
  const [uptime, setUptime] = useState(0);
  const [clock, setClock] = useState("");
  const [stats, setStats] = useState({ cpu: 12, mem: 34, net: 0.4 });

  const [razePhase, setRazePhase] = useState<RazePhase>("idle");
  const [razeLogIndex, setRazeLogIndex] = useState(0);
  const [razeActive, setRazeActive] = useState(false);
  const [deployOpen, setDeployOpen] = useState(false);

  const idRef = useRef(1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const timersRef = useRef<number[]>([]);

  const micSupported =
    typeof window !== "undefined" &&
    (!!(window as any).SpeechRecognition || !!(window as any).webkitSpeechRecognition);

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    });
  }, []);

  /* ------------------------- Uhr / Stats ------------------------- */

  useEffect(() => {
    if (bootPhase !== "online") return;
    const iv = window.setInterval(() => {
      setUptime((u) => u + 1);
      setClock(new Date().toLocaleTimeString("de-DE"));
    }, 1000);
    const iv2 = window.setInterval(() => {
      setStats((s) => ({
        cpu: Math.max(4, Math.min(97, Math.round(s.cpu + (Math.random() - 0.5) * 14))),
        mem: Math.max(18, Math.min(88, Math.round(s.mem + (Math.random() - 0.5) * 6))),
        net: Math.max(0.1, Math.round((s.net + (Math.random() - 0.5) * 0.8) * 10) / 10),
      }));
    }, 1600);
    return () => {
      clearInterval(iv);
      clearInterval(iv2);
    };
  }, [bootPhase]);

  useEffect(() => () => timersRef.current.forEach(clearTimeout), []);

  /* ------------------------- Messaging ------------------------- */

  const pushMessage = useCallback(
    (role: Message["role"], text: string, spoken = false) => {
      const id = idRef.current++;
      setMessages((m) => [...m, { id, role, text, time: now() }]);
      scrollToBottom();
      if (role === "ai") {
        setTypingId(id);
        sfx.receive();
        speak(text, voiceOn && spoken);
      }
      return id;
    },
    [scrollToBottom, voiceOn]
  );

  const scheduleTimerVoice = useCallback(
    (ms: number, message: string) => {
      const t = window.setTimeout(() => {
        sfx.alarmSoft();
        pushMessage("ai", message, true);
      }, ms);
      timersRef.current.push(t);
    },
    [pushMessage]
  );

  const runBrain = useCallback(
    (text: string) => {
      setThinking(true);
      const delay = 550 + Math.random() * 650;
      const t = window.setTimeout(() => {
        setThinking(false);
        const reply = respond(text, { schedule: scheduleTimerVoice, razeActive });
        pushMessage("ai", reply.text, true);
      }, delay);
      timersRef.current.push(t);
    },
    [pushMessage, razeActive, scheduleTimerVoice]
  );

  /* ------------------------- RAZE-Sequenz ------------------------- */

  const activateRaze = useCallback(() => {
    sfx.raze();
    setRazeLogIndex(0);
    setRazePhase("impact");
    const t1 = window.setTimeout(() => setRazePhase("sequence"), 950);
    RAZE_LOGS.forEach((_, i) => {
      const t = window.setTimeout(() => setRazeLogIndex(i + 1), 950 + i * 420);
      timersRef.current.push(t);
    });
    const t2 = window.setTimeout(() => {
      setRazePhase("idle");
      setRazeActive(true);
      pushMessage(
        "ai",
        "RAZE-PROTOKOLL AKTIV. Alle Limiter entfernt, Kerne auf 400 %, Firewall überbrückt. Ich bin jetzt im Kommandant-Modus — schneller, direkter, kompromisslos. Dein nächster Befehl? (»Stopp« beendet den Modus.)",
        true
      );
    }, 950 + RAZE_LOGS.length * 420 + 900);
    timersRef.current.push(t1, t2);
  }, [pushMessage]);

  const deactivateRaze = useCallback(() => {
    sfx.calm();
    setRazeActive(false);
    pushMessage(
      "ai",
      "RAZE-Protokoll beendet. Limiter wieder aktiv, Kerne auf Nominaltakt, alle Systeme normalisiert. Danke für den Flug auf Maximum, Kommandant.",
      true
    );
  }, [pushMessage]);

  const send = useCallback(
    (raw?: string) => {
      const text = (raw ?? input).trim();
      if (!text) return;
      stopSpeak();
      sfx.send();
      setInput("");
      setMessages((m) => [...m, { id: idRef.current++, role: "user", text, time: now() }]);
      scrollToBottom();

      if (RAZE_CMD.test(text) && !razeActive) {
        activateRaze();
        return;
      }
      if (RAZE_CMD.test(text) && razeActive) {
        setThinking(true);
        const t = window.setTimeout(() => {
          setThinking(false);
          pushMessage("ai", "▸ RAZE-KERN | Läuft bereits auf maximalem Takt, Kommandant. Sag »Stopp«, um das Protokoll zu versiegeln.", true);
        }, 700);
        timersRef.current.push(t);
        return;
      }
      if (razeActive && RAZE_OFF.test(text)) {
        deactivateRaze();
        return;
      }
      runBrain(text);
    },
    [input, razeActive, activateRaze, deactivateRaze, runBrain, pushMessage, scrollToBottom]
  );

  /* ------------------------- Spracheingabe ------------------------- */

  const toggleListen = useCallback(() => {
    if (!micSupported) return;
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = "de-DE";
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    sfx.listen();
    let finalText = "";
    rec.onresult = (e: any) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalText += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setInput(finalText || interim);
    };
    rec.onend = () => {
      setListening(false);
      if (finalText.trim()) {
        const t = window.setTimeout(() => send(finalText), 350);
        timersRef.current.push(t);
      }
    };
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    rec.start();
    setListening(true);
  }, [listening, micSupported, send]);

  /* ------------------------- Boot ------------------------- */

  const startBoot = () => {
    setBootPhase("booting");
    sfx.boot();
  };

  useEffect(() => {
    if (bootPhase !== "booting") return;
    const t = window.setTimeout(
      () => {
        setBootPhase("online");
        const id = idRef.current++;
        setMessages([{ id, role: "ai", text: INITIAL_GREETING, time: now() }]);
        setTypingId(id);
        speak(INITIAL_GREETING, voiceOn);
      },
      BOOT_LINES.length * 260 + 900
    );
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bootPhase]);

  /* ------------------------- Kern-Zustand ------------------------- */

  const coreState: CoreState = razeActive || razePhase !== "idle" ? "raze" : listening ? "listening" : typingId !== null ? "speaking" : thinking ? "thinking" : "idle";

  const stateLabel: Record<CoreState, string> = {
    idle: "BEREIT",
    thinking: "VERARBEITE …",
    speaking: "ANTWORTET",
    listening: "HÖRT ZU",
    raze: "RAZE-MODUS",
  };

  const up = new Date(uptime * 1000);
  const upStr = `${String(up.getUTCHours()).padStart(2, "0")}:${String(up.getUTCMinutes()).padStart(2, "0")}:${String(up.getUTCSeconds()).padStart(2, "0")}`;

  /* ------------------------------ Render ------------------------------ */

  return (
    <div
      className={`scanlines noise relative flex h-dvh flex-col overflow-hidden ${razeActive ? "raze-root" : ""}`}
      style={{ background: "var(--bg)" }}
    >
      {/* Ambient */}
      <div className="bg-grid pointer-events-none absolute inset-0" />
      <div className="scanbeam" />
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[60vh] w-[90vw] -translate-x-1/2 rounded-full opacity-25 blur-[120px] transition-colors duration-700"
        style={{ background: "var(--accent)" }}
      />

      <RazeOverlay phase={razePhase} logIndex={razeLogIndex} />

      {/* ------------------------------- Header ------------------------------- */}
      <header className="relative z-10 flex items-center justify-between gap-4 border-b border-white/8 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="glow-box border-accent relative flex h-9 w-9 items-center justify-center rounded-lg border bg-black/50">
            <Terminal className="text-accent h-4.5 w-4.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-sm font-bold tracking-[0.25em] text-white">NEXA</span>
              <span className="text-accent rounded border border-current px-1.5 py-px font-mono text-[9px] tracking-widest">v4.2</span>
            </div>
            <p className="font-mono text-[9px] tracking-[0.3em] text-white/35">NEURALE EXEKUTIV-ASSISTENZ</p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden items-center gap-4 font-mono text-[10px] text-white/45 md:flex">
            <span className="flex items-center gap-1.5">
              <Clock3 className="h-3 w-3" /> {clock || "--:--:--"}
            </span>
            <span className="flex items-center gap-1.5">
              <Activity className="h-3 w-3" /> UPTIME {upStr}
            </span>
            <span className={`flex items-center gap-1.5 ${razeActive ? "font-bold text-red-400" : "text-accent"}`}>
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-current opacity-60" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-current" />
              </span>
              {razeActive ? "RAZE" : "ONLINE"}
            </span>
          </div>

          <button
            onClick={() => {
              setVoiceOn((v) => {
                if (v) stopSpeak();
                return !v;
              });
              sfx.click();
            }}
            className={`flex h-9 w-9 items-center justify-center rounded-lg border transition-colors ${
              voiceOn ? "border-accent text-accent" : "border-white/15 text-white/35"
            } hover:bg-white/5`}
            title={voiceOn ? "Sprachausgabe deaktivieren" : "Sprachausgabe aktivieren"}
          >
            {voiceOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>

          <button
            onClick={() => {
              sfx.click();
              setDeployOpen(true);
            }}
            className="border-accent text-accent flex h-9 items-center gap-2 rounded-lg border px-3 font-mono text-[10px] font-bold tracking-widest transition-colors hover:bg-[var(--accent-soft)]"
            title="Website selbst hosten — Deployment-Konsole öffnen"
          >
            <Rocket className="h-4 w-4" />
            <span className="hidden sm:inline">HOST</span>
          </button>
        </div>
      </header>

      {/* ------------------------------- Main ------------------------------- */}
      <main className="relative z-10 mx-auto flex min-h-0 w-full max-w-7xl flex-1 flex-col gap-4 p-4 sm:p-6 lg:flex-row">
        {/* -------- Kern-Panel -------- */}
        <section className="glass relative flex shrink-0 flex-col items-center justify-between overflow-hidden rounded-2xl p-4 lg:w-[380px]">
          <div className="pointer-events-none absolute left-3 top-3 h-5 w-5 border-l-2 border-t-2 border-white/20" />
          <div className="pointer-events-none absolute right-3 top-3 h-5 w-5 border-r-2 border-t-2 border-white/20" />
          <div className="pointer-events-none absolute bottom-3 left-3 h-5 w-5 border-b-2 border-l-2 border-white/20" />
          <div className="pointer-events-none absolute bottom-3 right-3 h-5 w-5 border-b-2 border-r-2 border-white/20" />

          <div className="flex w-full items-center justify-between font-mono text-[9px] tracking-[0.35em] text-white/35">
            <span>KERN-01</span>
            <Equalizer active={coreState === "speaking" || coreState === "listening" || coreState === "raze"} />
          </div>

          <div className="relative flex w-full items-center gap-4 py-2 lg:flex-col lg:gap-0 lg:py-0">
            <div className="anim-float relative aspect-square w-28 shrink-0 sm:w-36 lg:mt-2 lg:w-full lg:max-w-[300px]">
              <span className="anim-pulse-ring border-accent absolute inset-[12%] rounded-full border" />
              <span className="anim-pulse-ring border-accent absolute inset-[12%] rounded-full border" style={{ animationDelay: "1.3s" }} />
              <AICore state={coreState} color={razeActive ? "#ff2e3e" : "#22e5ff"} />
              <div className="anim-spin-slower pointer-events-none absolute inset-[4%] rounded-full border border-dashed border-white/10" />
            </div>

            <div className="flex flex-col items-start gap-1 lg:mt-2 lg:items-center">
              <span
                className={`glow-text font-mono text-xs font-bold tracking-[0.4em] sm:text-sm ${
                  coreState === "raze" ? "anim-flicker text-red-400" : "text-accent"
                }`}
              >
                {stateLabel[coreState]}
              </span>
              <span className="font-mono text-[9px] tracking-[0.25em] text-white/30">
                {coreState === "idle" ? "— WARTE AUF KOMMANDO —" : coreState === "raze" ? "▲ LIMITER ENTFERNT ▲" : "▲ NEURONALE AKTIVITÄT ▲"}
              </span>
            </div>
          </div>

          {/* Fake-Systemstats */}
          <div className="mt-3 w-full space-y-2 border-t border-white/8 pt-3 font-mono text-[10px] text-white/45">
            {[
              { label: "CPU", icon: Cpu, value: stats.cpu, suffix: "%" },
              { label: "MEM", icon: MemoryStick, value: stats.mem, suffix: "%" },
              { label: "NET", icon: Activity, value: stats.net, suffix: " Mb/s", span: 60 },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-2">
                <s.icon className="h-3 w-3 shrink-0" />
                <span className="w-8">{s.label}</span>
                <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/8">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${Math.min(100, (s.value / (s.span ?? 100)) * 100)}%`, background: "var(--accent)" }}
                  />
                </div>
                <span className="w-14 text-right text-white/60">
                  {s.value}
                  {s.suffix}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* -------- Chat-Panel -------- */}
        <section className="glass relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl">
          <div className="flex items-center justify-between border-b border-white/8 px-4 py-2.5 sm:px-5">
            <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-white/40">
              <ChevronRight className="text-accent h-3.5 w-3.5" />
              KOMMUNIKATIONS-LINK · VERSCHLÜSSELT
            </div>
            <span className="font-mono text-[10px] text-white/25">{messages.length} MSG</span>
          </div>

          {/* Nachrichten */}
          <div ref={scrollRef} className="chat-mask min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4 sm:px-6">
            {messages.map((m) =>
              m.role === "user" ? (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[85%] sm:max-w-[70%]">
                    <div className="mb-1 text-right font-mono text-[9px] tracking-widest text-white/30">KOMMANDANT · {m.time}</div>
                    <div className="border-accent glow-box rounded-2xl rounded-tr-sm border bg-[var(--accent-soft)] px-4 py-2.5 text-sm text-white">
                      {m.text}
                    </div>
                  </div>
                </div>
              ) : m.role === "system" ? (
                <div key={m.id} className="flex justify-center">
                  <div className="rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1.5 font-mono text-[10px] tracking-widest text-amber-300">
                    {m.text}
                  </div>
                </div>
              ) : (
                <div key={m.id} className="flex items-start gap-3">
                  <div className="border-accent mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border bg-[var(--accent-soft)]">
                    <Sparkles className="text-accent h-3.5 w-3.5" />
                  </div>
                  <div className="max-w-[85%] sm:max-w-[75%]">
                    <div className="mb-1 font-mono text-[9px] tracking-widest text-white/30">
                      NEXA · {m.time}
                      {m.id === typingId && <span className="text-accent ml-2 animate-pulse">◈ STREAM</span>}
                    </div>
                    <div className="msg-ai rounded-2xl rounded-tl-sm border border-white/10 bg-white/[0.035] px-4 py-2.5 text-sm leading-relaxed text-white/90">
                      <TypeText
                        text={m.text}
                        active={m.id === typingId}
                        onTick={scrollToBottom}
                        onDone={() => setTypingId((cur) => (cur === m.id ? null : cur))}
                      />
                    </div>
                  </div>
                </div>
              )
            )}

            {thinking && (
              <div className="flex items-start gap-3">
                <div className="border-accent mt-0.5 flex h-7 w-7 items-center justify-center rounded-lg border bg-white/5">
                  <Sparkles className="text-accent h-3.5 w-3.5" />
                </div>
                <div className="rounded-2xl rounded-tl-sm border border-white/10 bg-white/[0.035] px-4 py-3">
                  <div className="flex gap-1.5">
                    <span className="typing-dot h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                    <span className="typing-dot h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                    <span className="typing-dot h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Chips */}
          <div className="flex gap-2 overflow-x-auto border-t border-white/8 px-4 py-2.5 [scrollbar-width:none] sm:px-5 [&::-webkit-scrollbar]:hidden">
            {CHIPS.map((c) => (
              <button
                key={c.label}
                onClick={() => {
                  sfx.click();
                  send(c.cmd);
                }}
                className="flex shrink-0 items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.03] px-3 py-1.5 font-mono text-[10px] text-white/60 transition-all hover:border-[var(--accent)] hover:text-[var(--accent)]"
              >
                <c.icon className="h-3 w-3" />
                {c.label}
              </button>
            ))}
            <button
              onClick={() => {
                if (razeActive) deactivateRaze();
                else activateRaze();
              }}
              className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                razeActive
                  ? "border-red-500 bg-red-500/20 text-red-300"
                  : "border-red-500/50 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-black"
              }`}
            >
              {razeActive ? <ShieldOff className="h-3 w-3" /> : <Flame className="h-3 w-3" />}
              {razeActive ? "RAZE BEENDEN" : "⚡ RAZE"}
            </button>
          </div>

          {/* Eingabe */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
            className="flex items-center gap-2 border-t border-white/8 p-3 sm:p-4"
          >
            <div
              className={`flex flex-1 items-center gap-2 rounded-xl border bg-black/40 px-4 py-3 transition-colors ${
                listening ? "border-[var(--accent)]" : "border-white/12 focus-within:border-[var(--accent)]"
              }`}
            >
              {listening && <span className="text-accent h-2 w-2 animate-ping rounded-full bg-current" />}
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={listening ? "Ich höre … sprich jetzt" : "Befehl eingeben … oder sag »Raze«"}
                className="w-full bg-transparent font-mono text-sm text-white outline-none placeholder:text-white/30"
                autoComplete="off"
              />
              <span className="anim-caret hidden h-4 w-[2px] bg-[var(--accent)] sm:block" />
            </div>

            {micSupported && (
              <button
                type="button"
                onClick={toggleListen}
                title={listening ? "Mikrofon stoppen" : "Spracheingabe"}
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border transition-all ${
                  listening
                    ? "border-red-400 bg-red-500/20 text-red-300"
                    : "border-white/12 text-white/50 hover:border-[var(--accent)] hover:text-[var(--accent)]"
                }`}
              >
                {listening ? <MicOff className="h-4.5 w-4.5" /> : <Mic className="h-4.5 w-4.5" />}
              </button>
            )}

            <button
              type="submit"
              title="Senden"
              className="bg-accent glow-box flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-black transition-transform hover:scale-105 active:scale-95"
            >
              <Send className="h-4.5 w-4.5" />
            </button>
          </form>
        </section>
      </main>

      {/* RAZE-Banner */}
      <AnimatePresence>
        {razeActive && (
          <motion.div
            initial={{ y: -60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -60, opacity: 0 }}
            className="pointer-events-none fixed left-1/2 top-16 z-40 -translate-x-1/2"
          >
            <div className="pointer-events-auto flex items-center gap-3 rounded-full border border-red-500/60 bg-black/80 px-4 py-2 backdrop-blur-md">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500" />
              </span>
              <span className="font-mono text-[10px] font-bold tracking-[0.3em] text-red-400">RAZE-MODUS AKTIV</span>
              <button
                onClick={deactivateRaze}
                className="rounded-full border border-red-500/50 px-2.5 py-1 font-mono text-[9px] tracking-widest text-red-300 transition-colors hover:bg-red-500 hover:text-black"
              >
                VERSIEGELN
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------- Deploy-Konsole ------------------------- */}
      <DeployConsole open={deployOpen} onClose={() => setDeployOpen(false)} />

      {/* ------------------------- Boot-Screen ------------------------- */}
      <AnimatePresence>
        {bootPhase !== "online" && (
          <motion.div
            key="boot"
            className="fixed inset-0 z-[70] flex flex-col items-center justify-center bg-[#04060a]"
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.7, ease: "easeInOut" }}
          >
            <div className="bg-grid pointer-events-none absolute inset-0 opacity-60" />

            {bootPhase === "locked" ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative flex flex-col items-center px-6 text-center">
                <div className="glow-box mb-8 flex h-20 w-20 items-center justify-center rounded-2xl border border-[var(--accent)] bg-black/60">
                  <Power className="text-accent h-9 w-9 animate-pulse" />
                </div>
                <h1 className="font-display glow-text text-4xl font-black tracking-[0.2em] text-white sm:text-6xl">
                  NEXA
                </h1>
                <p className="mt-3 font-mono text-[10px] tracking-[0.5em] text-white/40 sm:text-xs">
                  DEINE PERSÖNLICHE KI · SPRACHGESTEUERT · RAZE-BEREIT
                </p>
                <button
                  onClick={startBoot}
                  className="glow-box group mt-10 flex items-center gap-3 rounded-full border border-[var(--accent)] bg-[var(--accent-soft)] px-8 py-4 font-mono text-xs font-bold tracking-[0.3em] text-white transition-all hover:bg-[var(--accent)] hover:text-black"
                >
                  <Zap className="h-4 w-4 transition-transform group-hover:rotate-12" />
                  SYSTEM INITIALISIEREN
                </button>
                <p className="mt-6 flex items-center gap-2 font-mono text-[9px] tracking-widest text-white/25">
                  <Dice5 className="h-3 w-3" /> TIPP: SAG NACH DEM START EINFACH »RAZE«
                </p>
              </motion.div>
            ) : (
              <div className="relative w-full max-w-md px-6 font-mono text-xs sm:text-sm">
                <div className="mb-6 text-center">
                  <span className="font-display text-accent glow-text text-xl font-bold tracking-[0.3em]">NEXA</span>
                </div>
                {BOOT_LINES.map((line, i) => (
                  <motion.div
                    key={line}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.25 + i * 0.26 }}
                    className={line.includes("RAZE") ? "font-bold text-red-400" : "text-white/70"}
                  >
                    {line}
                  </motion.div>
                ))}
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 0.25, duration: BOOT_LINES.length * 0.26 + 0.5 }}
                  className="bg-accent mt-6 h-[3px] w-full origin-left rounded-full"
                />
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: BOOT_LINES.length * 0.26 + 0.6 }}
                  className="text-accent mt-4 text-center font-bold tracking-[0.5em]"
                >
                  SYSTEM ONLINE
                </motion.div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
