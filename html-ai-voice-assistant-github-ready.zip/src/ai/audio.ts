/* ----------------------------------------------------------
   NEXA AUDIO — Web-Audio-Soundengine (keine Assets nötig)
---------------------------------------------------------- */

let ctx: AudioContext | null = null;

function ac(): AudioContext {
  if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function tone(freq: number, dur: number, type: OscillatorType = "sine", gain = 0.06, when = 0, slideTo?: number) {
  try {
    const a = ac();
    const t0 = a.currentTime + when;
    const osc = a.createOscillator();
    const g = a.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(a.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  } catch {
    /* audio unavailable */
  }
}

export const sfx = {
  /** Klick beim Senden */
  send() {
    tone(880, 0.09, "square", 0.028);
    tone(1320, 0.12, "sine", 0.035, 0.05);
  },
  /** Antwort der KI */
  receive() {
    tone(523.25, 0.1, "sine", 0.04);
    tone(783.99, 0.14, "sine", 0.04, 0.09);
  },
  /** Tastenklick */
  click() {
    tone(1800, 0.03, "square", 0.015);
  },
  /** Mikro aktiv */
  listen() {
    tone(440, 0.12, "sine", 0.05, 0, 880);
  },
  /** Timer abgelaufen */
  alarmSoft() {
    [0, 0.18, 0.36].forEach((d) => tone(1046, 0.16, "triangle", 0.06, d));
  },
  /** Boot-Sequenz */
  boot() {
    tone(220, 0.4, "sine", 0.04, 0, 440);
    tone(440, 0.35, "sine", 0.035, 0.25, 880);
    tone(880, 0.5, "sine", 0.03, 0.55, 1760);
  },
  /** RAZE-Alarm */
  raze() {
    for (let i = 0; i < 4; i++) {
      tone(160, 0.3, "sawtooth", 0.07, i * 0.34, 420);
      tone(60, 0.34, "square", 0.05, i * 0.34, 55);
    }
    tone(2093, 0.5, "sine", 0.045, 1.4);
    tone(2637, 0.6, "sine", 0.04, 1.55);
  },
  /** RAZE beenden */
  calm() {
    tone(660, 0.25, "sine", 0.05, 0, 330);
    tone(330, 0.4, "sine", 0.04, 0.2, 165);
  },
};

/* -------------------- Text to Speech (deutsch) -------------------- */

let voice: SpeechSynthesisVoice | null = null;

function pickVoice() {
  if (typeof speechSynthesis === "undefined") return;
  const voices = speechSynthesis.getVoices();
  voice =
    voices.find((v) => v.lang.startsWith("de") && /female|anna|petra|marlene|vicki|katja/i.test(v.name)) ||
    voices.find((v) => v.lang === "de-DE") ||
    voices.find((v) => v.lang.startsWith("de")) ||
    null;
}

if (typeof speechSynthesis !== "undefined") {
  pickVoice();
  speechSynthesis.onvoiceschanged = pickVoice;
}

export function speak(text: string, enabled: boolean, onEnd?: () => void) {
  if (!enabled || typeof speechSynthesis === "undefined") {
    onEnd?.();
    return;
  }
  try {
    speechSynthesis.cancel();
    const clean = text.replace(/[▸•♪⚄]/g, "").slice(0, 400);
    const u = new SpeechSynthesisUtterance(clean);
    if (voice) u.voice = voice;
    u.lang = "de-DE";
    u.rate = 1.04;
    u.pitch = 1.02;
    u.onend = () => onEnd?.();
    u.onerror = () => onEnd?.();
    speechSynthesis.speak(u);
  } catch {
    onEnd?.();
  }
}

export function stopSpeak() {
  try {
    if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
  } catch {
    /* noop */
  }
}
