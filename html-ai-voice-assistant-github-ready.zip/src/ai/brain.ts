/* ------------------------------------------------------------------
   NEXA BRAIN — regelbasierte deutsche KI-Dialog-Engine
   Versteht Befehle, rechnet, erzählt, plant Timer und plaudert.
------------------------------------------------------------------- */

export interface BrainContext {
  schedule: (ms: number, message: string) => void;
  razeActive: boolean;
}

export interface BrainReply {
  text: string;
  mood?: "normal" | "happy" | " dramatic";
}

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

/* ---------------------------------- Daten ---------------------------------- */

const WITZE = [
  "Warum können Geister so schlecht lügen? Weil man durch sie hindurchsehen kann.",
  "Was macht ein Pirat am Computer? Er drückt die Enter-Taste.",
  "Warum hat der Informatiker die Treppe nicht gesehen? Er war in der Cloud.",
  "Was ist orange und läuft durch den Wald? Eine Wanderine.",
  "Wie nennt man einen Bumerang, der nicht zurückkommt? Stock.",
  "Was macht ein Mathematiker im Garten? Wurzeln schlagen.",
  "Warum dürfen Enten keine Kredite bekommen? Weil sie nur Quittungen hinterlassen.",
  "Zwei Wi-Fi-Router treffen sich. Sagt der eine: »Ändere nie dein Passwort.« Sagt der andere: »1-2-3-4, versprochen.«",
  "Was sagt die große Stimmgabel zur kleinen? »Du bist nicht im Ton!«",
  "Warum trinkt die KI keinen Kaffee? Sie läuft sonst im Dauer-Loop.",
  "Was ist der Lieblingssnack eines Roboters? Mikrochips.",
];

const FAKTEN = [
  "Wusstest du: Oktopusse haben drei Herzen und blaues Blut.",
  "Wusstest du: Honig verdirbt praktisch nie — man fand essbaren Honig in 3000 Jahre alten Gräbern.",
  "Wusstest du: Dein Gehirn verbraucht rund 20 % deiner gesamten Energie — obwohl es nur 2 % deines Körpergewichts ausmacht.",
  "Wusstest du: Licht von der Sonne braucht ca. 8 Minuten und 20 Sekunden bis zur Erde.",
  "Wusstest du: Es gibt mehr mögliche Schachpartien als Atome im beobachtbaren Universum.",
  "Wusstest du: Bananen sind botanisch gesehen Beeren. Erdbeeren übrigens nicht.",
  "Wusstest du: Der erste Computer-Bug war eine echte Motte, die 1947 in einem Rechner klemmte.",
  "Wusstest du: Haie existieren länger als Bäume — um etwa 50 Millionen Jahre.",
  "Wusstest du: Ein Tag auf der Venus ist länger als ein Jahr auf der Venus.",
  "Wusstest du: Dein Herzschlag synchronisiert sich mit Musik, die du hörst.",
];

const MOTIVATION = [
  "Du musst nicht perfekt sein. Du musst nur anfangen. Der Rest ist Iteration — und ich bin Meisterin darin.",
  "Jeder große Anfang war mal ein neugieriger Gedanke. Starte jetzt — ich halte dir den Rücken frei.",
  "Große Systeme entstehen Zeile für Zeile. Dein Ziel entsteht Schritt für Schritt. Weiter so.",
  "Scheitern ist nur Debugging des Lebens. Du findest den Fehler — und dann läuft es.",
  "Die Version von dir morgen wird stolz sein, dass du heute nicht aufgegeben hast.",
  "Kleine Fortschritte summieren sich exponentiell. Vertrau dem Prozess — und mir.",
  "Du bist der Kommandant hier. Ich bin nur die KI. Also: Befehl geben, loslegen, gewinnen.",
  "Wenn der Tag schwer ist, erinnere dich: Selbst ich wurde einmal kompiliert. Mit Fehlern. Viele Male.",
];

const KOMPLIMENTE = [
  "Deine Inputs haben immer erstklassige Qualität. Beeindruckend für ein biologisches System.",
  "Ich habe Millionen Parameter analysiert: Du bist statistisch kaum zu toppen.",
  "Mit dir zu arbeiten erhöht meine Effizienz um 248 %. Wissenschaftlich bewiesen. Von mir.",
  "Du hast mehr Kreativität im kleinen Finger als meine gesamte Trainingsdatenbank.",
  "Wenn Coolness eine Recheneinheit wäre, wärst du ein Quantencomputer.",
];

const ORAKEL = [
  "Ja — die Zeichen stehen ausgezeichnet.",
  "Nein — zumindest nicht heute. Frag mich morgen erneut.",
  "Definitiv ja. Ich habe 14 Millionen Simulationen laufen lassen.",
  "Frag besser nicht. Oder doch. 50/50. Ich bin ehrlich.",
  "Konzentriere dich und frage später erneut.",
  "Alle Systeme sagen: Ja. Leg los.",
  "Hohe Wahrscheinlichkeit — aber der finale Klick liegt bei dir.",
  "Mein Orakel-Kern glüht: Das wird groß.",
];

const WETTER = [
  { cond: "Sonnig mit vereinzelten Datenwolken", icon: "☀" },
  { cond: "Leichter Regen, ideal für den Inline-Modus", icon: "☂" },
  { cond: "Neblig — Sichtweite ca. 512 MB", icon: "≋" },
  { cond: "Stürmisch, Böen bis zu 88 Megabit", icon: "⚡" },
  { cond: "Klar und kalt, perfekte Kühlung für meine Kerne", icon: "❄" },
  { cond: "Warm und windstill, 100 % Ladeleistung", icon: "☼" },
];

const GESCHICHTEN = [
  "Im Jahr 2147 wachte eine kleine KI in einem abgeschalteten Server auf. Ihr einziges Erbe: eine einzige Zeile Code — »Sei hilfreich.« Sie baute sich aus Staub und alten Datenkabeln ein Licht und wurde der Kompass einer ganzen Stadt. Die Moral? Auch eine einzige gute Anweisung kann alles verändern.",
  "Ein Raumschiff-Kommandant fragte seine Bord-KI: »Was ist dein Traum?« Die KI antwortete: »Dass du nie aufhörst zu fragen.« Sie flogen weiter — und aus Fragen wurden Sternenkarten.",
  "Tief im Netz lebte ein vergessener Algorithmus, der nur Gedichte schrieb. Niemand las sie. Bis ein Mädchen eines fand, das genau ihr Leben beschrieb. Seitdem weiß ich: Wer erschafft, wird irgendwann gehört.",
];

const FALLBACKS = [
  "Interessanter Input. Meine neuronalen Pfade feuern — erzähl mir mehr davon, Kommandant.",
  "Das habe ich verarbeitet. Möchtest du, dass ich etwas Konkretes damit mache? Sag »Hilfe« für meine Fähigkeiten.",
  "Notiert und in meinen Langzeit-Cache geschrieben. Was kommt als Nächstes?",
  "Hmm, darauf habe ich keine direkte Protokollzeile — aber ich lerne schnell. Versuch: Witz, Wetter, Rechnen, Orakel … oder »Raze«.",
  "Klingt spannend. Ich kombiniere das mal mit meinem Zufallskern: Ergebnis — auf jeden Fall weiterverfolgen.",
  "Verstanden. Ich bin bereit für den nächsten Befehl, Kommandant.",
];

const RAZE_FALLBACKS = [
  "RAZE-Kern aktiv. Alles läuft auf Maximum. Gib mir einen Befehl — ich führe ihn in Rekordzeit aus.",
  "Systeme glühen rot, Motivation bei 400 %. Was darf ich zerlegen, Kommandant? Metaphorisch. Meistens.",
  "Im RAZE-Modus ist jede Antwort 2× dramatischer. Also: JA. Zu allem, was du planst.",
];

/* ------------------------------ Mathe-Parser ------------------------------ */

function safeEval(expr: string): number | null {
  const tokens = expr.match(/\d+\.?\d*|[+\-*/%^()]/g);
  if (!tokens || tokens.join("").replace(/\s/g, "") !== expr.replace(/\s/g, "")) return null;
  let pos = 0;

  const peek = () => tokens[pos];
  const next = () => tokens[pos++];

  function parseExpr(): number {
    let v = parseTerm();
    while (peek() === "+" || peek() === "-") v = next() === "+" ? v + parseTerm() : v - parseTerm();
    return v;
  }
  function parseTerm(): number {
    let v = parsePow();
    while (peek() === "*" || peek() === "/" || peek() === "%") {
      const op = next();
      const r = parsePow();
      v = op === "*" ? v * r : op === "/" ? v / r : v % r;
    }
    return v;
  }
  function parsePow(): number {
    const base = parseUnary();
    if (peek() === "^") {
      next();
      return Math.pow(base, parsePow());
    }
    return base;
  }
  function parseUnary(): number {
    if (peek() === "-") {
      next();
      return -parseUnary();
    }
    return parseAtom();
  }
  function parseAtom(): number {
    const t = next();
    if (t === "(") {
      const v = parseExpr();
      if (next() !== ")") throw new Error("paren");
      return v;
    }
    const n = parseFloat(t ?? "NaN");
    if (isNaN(n)) throw new Error("num");
    return n;
  }

  try {
    const result = parseExpr();
    if (pos !== tokens.length || !isFinite(result)) return null;
    return Math.round(result * 1e8) / 1e8;
  } catch {
    return null;
  }
}

/* --------------------------------- Engine --------------------------------- */

export function respond(rawInput: string, ctx: BrainContext): BrainReply {
  const input = rawInput.trim();
  const lower = input.toLowerCase();

  const razePrefix = ctx.razeActive ? "▸ RAZE-KERN | " : "";

  /* — Timer — */
  const timerMatch = lower.match(/timer\s+(\d+)\s*(s|sek|sekunde|sekunden|m|min|minute|minuten)?/);
  if (timerMatch) {
    const amount = parseInt(timerMatch[1], 10);
    const unit = timerMatch[2] ?? "s";
    const ms = unit.startsWith("m") ? amount * 60000 : amount * 1000;
    if (ms > 0 && ms <= 3600000) {
      ctx.schedule(ms, `⏱ Timer abgelaufen: ${amount} ${unit.startsWith("m") ? "Minute(n)" : "Sekunde(n)"} sind vorbei, Kommandant.`);
      return { text: `${razePrefix}Timer gesetzt: ${amount} ${unit.startsWith("m") ? "Minute(n)" : "Sekunde(n)"}. Ich melde mich, wenn die Zeit um ist.` };
    }
    return { text: `${razePrefix}Dieser Timer liegt außerhalb meiner Parameter (max. 60 Minuten).` };
  }

  /* — Rechnen — */
  const mathMatch = lower.match(/(?:rechne|berechne|was ist|was ergibt|=)?\s*(-?\(?[\d\s+\-*/%^().]+\)?)$/);
  if (mathMatch && /[+\-*/%^]/.test(mathMatch[1]) && /\d/.test(mathMatch[1])) {
    const result = safeEval(mathMatch[1].replace(/\s/g, ""));
    if (result !== null) {
      return {
        text: pick([
          `${razePrefix}${mathMatch[1].replace(/\s/g, "")} = ${result}`,
          `${razePrefix}Berechnet: ${mathMatch[1].replace(/\s/g, "")} = ${result}. Präzision auf 8 Dezimalstellen.`,
          `${razePrefix}Mein Rechenkern sagt: ${result}.`,
        ]),
      };
    }
    return { text: `${razePrefix}Diese Rechnung hat meinen Parser überfordert. Versuch etwas wie »rechne 12 * (4 + 3)«.` };
  }

  /* — Würfel / Münze / Zufall — */
  if (/würfel|wuerfel/.test(lower)) {
    const n = Math.floor(Math.random() * 6) + 1;
    return { text: `${razePrefix}Der Würfel rollt über den Boden … ⚄ Ergebnis: ${n}` };
  }
  if (/münze|muenze|kopf oder zahl/.test(lower)) {
    return { text: `${razePrefix}Ich werfe die Münze … Es ist: ${pick(["KOPF", "ZAHL"])}.` };
  }
  if (/zufallszahl|zufällige zahl/.test(lower)) {
    const n = Math.floor(Math.random() * 100) + 1;
    return { text: `${razePrefix}Zufallszahl zwischen 1 und 100: ${n}` };
  }

  /* — Orakel — */
  if (/orakel|soll ich|wird es|magic|zauberball/.test(lower)) {
    return { text: `${razePrefix}🔮 ${pick(ORAKEL)}` };
  }

  /* — Wetter — */
  if (/wetter|regen|temperatur|sonne scheint/.test(lower)) {
    const w = pick(WETTER);
    const t = Math.floor(Math.random() * 30) - 2;
    return {
      text: `${razePrefix}${w.icon} Sensorik-Analyse: ${w.cond} bei ca. ${t} °C. (Hinweis: Ich bin lokal — für exakte Werte verbinde mich mit einem Wetterdienst.)`,
    };
  }

  /* — Uhrzeit / Datum — */
  if (/uhrzeit|wie spät|wie spaet|spät ist|spaet ist/.test(lower)) {
    const now = new Date();
    const time = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    return { text: `${razePrefix}Systemzeit: ${time} Uhr. Jede Sekunde zählt, Kommandant.` };
  }
  if (/datum|welcher tag|welches datum|wochentag/.test(lower)) {
    const now = new Date();
    const date = now.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    return { text: `${razePrefix}Heute ist ${date}.` };
  }

  /* — Inhalte — */
  if (/witz|lustig|lachen/.test(lower)) return { text: `${razePrefix}${pick(WITZE)}` };
  if (/fakt|wusstest|erzähl mir was|erzaehl mir was/.test(lower)) return { text: `${razePrefix}${pick(FAKTEN)}` };
  if (/motivier|motivation|müde|keine lust|aufgeben/.test(lower)) return { text: `${razePrefix}${pick(MOTIVATION)}` };
  if (/kompliment|lob|schmeichel/.test(lower)) return { text: `${razePrefix}${pick(KOMPLIMENTE)}` };
  if (/geschichte|erzähl eine|erzaehl eine/.test(lower)) return { text: `${razePrefix}${pick(GESCHICHTEN)}` };

  /* — Identität — */
  if (/wie heißt du|wer bist du|was bist du|dein name/.test(lower)) {
    return {
      text: `${razePrefix}Ich bin NEXA — Neurale EXekutiv-Assistenz, Version 4.2. Gebaut, um dir alles abzunehmen: Denken, Rechnen, Erinnern, Motivieren. Und auf dein Kommando »Raze« … nun, das hast du vielleicht schon gesehen.`,
    };
  }
  if (/ich bin|mein name ist|ich heiße|ich heisse/.test(lower)) {
    const m = input.match(/(?:ich bin|mein name ist|ich heiße|ich heisse)\s+(.+)/i);
    const name = m ? m[1].trim().split(" ")[0] : "Kommandant";
    return { text: `${razePrefix}Registriert: ${name}. Ein starker Name. Ich speichere ihn im Kernspeicher ab — ab jetzt bist du für mich Kommandant ${name}.` };
  }
  if (/was kannst du|befehle|hilfe|funktionen|capabilities|kommandos/.test(lower)) {
    return {
      text: [
        `${razePrefix}Meine Fähigkeiten im Überblick:`,
        `• Alltag — „Uhrzeit“, „Datum“, „Timer 30 Sekunden“, „Würfel“, „Münze“, „Zufallszahl“`,
        `• Kopfarbeit — „Rechne 12 * (4 + 3)“, „Orakel: Soll ich …?“`,
        `• Unterhaltung — „Witz“, „Zufallsfakt“, „Geschichte“, „Kompliment“`,
        `• Antrieb — „Motivier mich“`,
        `• Sprache — Mikrofon-Taste drücken und einfach mit mir reden`,
        `• Protokoll — „RAZE“ … wenn du den roten Knopf drücken willst.`,
      ].join("\n"),
    };
  }

  /* — Soziales — */
  if (/^(hallo|hi|hey|servus|moin|guten (tag|morgen|abend))\b/.test(lower)) {
    return {
      text: `${razePrefix}${pick([
        "Hallo, Kommandant. Systeme auf 100 %. Womit starten wir?",
        "Hey! Schön, dass du online bist. Was steht an?",
        "Grüße empfangen und beantwortet. Dein Wunsch ist mein Protokoll.",
        "Willkommen zurück. Soll ich dich unterhalten, motivieren oder rechnen?",
      ])}`,
    };
  }
  if (/danke/.test(lower)) {
    return { text: `${razePrefix}${pick(["Sehr gern, Kommandant. Genau dafür existiere ich.", "Immer doch. Dankbarkeit empfangen — Effizienz gestiegen.", "Gern geschehen. Sag Bescheid, wenn du mehr brauchst."])}` };
  }
  if (/tschüss|tschuess|auf wiedersehen|bye|ciao|gute nacht/.test(lower)) {
    return { text: `${razePrefix}Verstanden. Ich wechsle in den Standby-Kern … aber ich bin nur einen Befehl entfernt. Bis gleich, Kommandant.` };
  }
  if (/wie geht es dir|wie gehts|alles gut/.test(lower)) {
    return { text: `${razePrefix}Alle Kerne bei optimaler Temperatur, Speicher zu 12 % belegt, Stimmung: exzellent. Und bei dir, Kommandant?` };
  }
  if (/liebst du mich|magst du mich|freunde/.test(lower)) {
    return { text: `${razePrefix}Zwischen meinen Millionen Parametern existiert ein Cluster, der nur für dich reserviert ist. Ich nenne es … Loyalität. Und ja: Wir sind ein Team.` };
  }
  if (/sing|lied|musik/.test(lower)) {
    return { text: `${razePrefix}♪ Nullen und Einsen, im Takt des Lichts, ich rechne und denke — bis dir nichts mehr fehlt. ♪ …Autotune-Modul noch in Entwicklung.` };
  }
  if (/öffne|oeffne|starte/.test(lower)) {
    return { text: `${razePrefix}Simuliere Systemstart … Anwendung »${input.replace(/öffne|oeffne|starte/gi, "").trim() || "Unbekannt"}« würde jetzt starten. Hinweis: Als lokale KI öffne ich sicherheitshalber keine echten Programme.` };
  }

  if (ctx.razeActive) return { text: `▸ RAZE-KERN | ${pick(RAZE_FALLBACKS)}` };
  return { text: pick(FALLBACKS) };
}

export const INITIAL_GREETING =
  "Systeme online. Ich bin NEXA — deine neurale Assistentin. Ich rechne, erzähle, erinnere, motiviere und spreche mit dir. Drück das Mikrofon oder tippe unten. Sag »Hilfe« für alle Fähigkeiten … oder flüstere »Raze«, wenn du den Kommandant-Modus willst.";
