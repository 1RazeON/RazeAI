import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  Copy,
  Container,
  Globe,
  HardDrive,
  Rocket,
  Server,
  X,
} from "lucide-react";

/* --------------------------- Codeblock --------------------------- */

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="group relative mt-2 overflow-hidden rounded-lg border border-white/12 bg-black/70">
      <div className="flex items-center justify-between border-b border-white/8 px-3 py-1.5">
        <div className="flex gap-1.5">
          <span className="h-2 w-2 rounded-full bg-red-500/70" />
          <span className="h-2 w-2 rounded-full bg-amber-400/70" />
          <span className="h-2 w-2 rounded-full bg-emerald-400/70" />
        </div>
        <button
          onClick={copy}
          className="flex items-center gap-1 rounded px-2 py-0.5 font-mono text-[9px] tracking-widest text-white/40 transition-colors hover:bg-white/10 hover:text-white"
        >
          {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
          {copied ? "KOPIERT" : "COPY"}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 font-mono text-[11px] leading-relaxed text-[var(--accent)] sm:text-xs">
        <code>{code}</code>
      </pre>
    </div>
  );
}

/* ---------------------------- Inhalte ---------------------------- */

interface Tab {
  id: string;
  label: string;
  icon: any;
  intro: string;
  steps: { title: string; desc?: string; code?: string }[];
}

const TABS: Tab[] = [
  {
    id: "local",
    label: "Eigenes Gerät",
    icon: HardDrive,
    intro: "Hoste NEXA auf deinem PC, Laptop oder Raspberry Pi — im Heimnetz sofort erreichbar.",
    steps: [
      {
        title: "1 · Projekt bauen",
        desc: "Erzeugt den fertigen »dist«-Ordner — das ist die komplette Website.",
        code: "npm install\nnpm run build",
      },
      {
        title: "2 · Server starten",
        desc: "Ein einziger Befehl stellt die Seite auf Port 3000 bereit.",
        code: "npx serve dist -l 3000",
      },
      {
        title: "3 · Aufrufen",
        desc: "Am selben Gerät: http://localhost:3000 — Handy im selben WLAN: deine IP statt localhost.",
        code: "# IP herausfinden\nipconfig            # Windows\nip addr | grep inet # Linux / macOS",
      },
      {
        title: "4 · Dauerhaft online (optional)",
        desc: "Mit Dynamic-DNS (z. B. DuckDNS) + Portfreigabe am Router erreichst du sie von überall.",
      },
    ],
  },
  {
    id: "static",
    label: "Statischer Host",
    icon: Globe,
    intro: "Der einfachste Weg ins öffentliche Internet — kostenlos, in unter 2 Minuten, eigene Subdomain inklusive.",
    steps: [
      {
        title: "1 · Build erzeugen",
        code: "npm run build",
      },
      {
        title: "2 · Netlify Drop (ohne Account-Klimbim)",
        desc: "Zieh den Ordner »dist« per Drag & Drop auf netlify.com/drop — live in Sekunden.",
      },
      {
        title: "3 · Alternativ per CLI",
        code: "npm i -g netlify-cli\nnetlify deploy --dir=dist --prod\n\n# oder Vercel:\nnpm i -g vercel\nvercel deploy dist --prod",
      },
      {
        title: "4 · GitHub Pages",
        code: "npm i -g gh-pages\ngh-pages -d dist\n# → https://deinname.github.io/repo",
      },
    ],
  },
  {
    id: "vps",
    label: "Eigener Server",
    icon: Server,
    intro: "Volle Kontrolle: VPS (Hetzner, Netcup & Co.) mit nginx — Profi-Variante für Option B.",
    steps: [
      {
        title: "1 · Build auf den Server kopieren",
        code: "npm run build\nscp -r dist/* user@dein-server:/var/www/nexa",
      },
      {
        title: "2 · nginx-Konfiguration",
        code: "server {\n  listen 80;\n  server_name deine-domain.de;\n  root /var/www/nexa;\n  index index.html;\n  location / { try_files $uri /index.html; }\n}",
      },
      {
        title: "3 · Gratis-HTTPS mit Let's Encrypt",
        code: "sudo certbot --nginx -d deine-domain.de\nsudo systemctl reload nginx",
      },
    ],
  },
  {
    id: "docker",
    label: "Docker",
    icon: Container,
    intro: "Portabel hosten — ein Image, das überall läuft: NAS, Server, Cloud, Raspberry Pi.",
    steps: [
      {
        title: "1 · Dockerfile anlegen (Projektwurzel)",
        code: "FROM nginx:alpine\nCOPY dist /usr/share/nginx/html\nEXPOSE 80",
      },
      {
        title: "2 · Image bauen",
        code: "npm run build\ndocker build -t nexa .",
      },
      {
        title: "3 · Container starten",
        code: "docker run -d -p 8080:80 --name nexa --restart unless-stopped nexa",
      },
      {
        title: "4 · Fertig",
        desc: "NEXA läuft jetzt unter http://localhost:8080 — und startet nach jedem Neustart automatisch neu.",
      },
    ],
  },
];

/* --------------------------- Komponente --------------------------- */

export default function DeployConsole({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [active, setActive] = useState("local");
  const tab = TABS.find((t) => t.id === active)!;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 220, damping: 24 }}
            className="glass relative flex max-h-full w-full max-w-3xl flex-col overflow-hidden rounded-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <div className="flex items-center gap-3">
                <div className="glow-box border-accent flex h-9 w-9 items-center justify-center rounded-lg border bg-black/50">
                  <Rocket className="text-accent h-4 w-4" />
                </div>
                <div>
                  <h2 className="font-display glow-text text-sm font-bold tracking-[0.25em] text-white">SELF-HOST PROTOCOL</h2>
                  <p className="font-mono text-[9px] tracking-[0.3em] text-white/35">OPTION B · NEXA AUF EIGENER INFRASTRUKTUR</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/12 text-white/50 transition-colors hover:border-[var(--accent)] hover:text-[var(--accent)]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 overflow-x-auto border-b border-white/8 px-5 py-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActive(t.id)}
                  className={`flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 font-mono text-[10px] tracking-wider transition-all ${
                    active === t.id
                      ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent)]"
                      : "border-white/12 text-white/45 hover:text-white"
                  }`}
                >
                  <t.icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              ))}
            </div>

            {/* Inhalt */}
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              <AnimatePresence mode="wait">
                <motion.div
                  key={tab.id}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }}
                  transition={{ duration: 0.22 }}
                >
                  <p className="mb-4 text-sm leading-relaxed text-white/65">{tab.intro}</p>
                  <div className="space-y-4">
                    {tab.steps.map((s) => (
                      <div key={s.title} className="rounded-xl border border-white/8 bg-white/[0.02] p-3.5">
                        <h3 className="font-mono text-[11px] font-bold tracking-widest text-white">{s.title}</h3>
                        {s.desc && <p className="mt-1.5 text-xs leading-relaxed text-white/50">{s.desc}</p>}
                        {s.code && <CodeBlock code={s.code} />}
                      </div>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Footer */}
            <div className="border-t border-white/8 px-5 py-3">
              <p className="font-mono text-[9px] leading-relaxed tracking-wider text-white/30">
                ▸ HINWEIS: Diese Vorschau läuft auf der Sandbox-Infrastruktur. Für Option B lädst du die Projektdateien
                herunter, führst »npm run build« aus — und der »dist«-Ordner ist deine fertige, überall hostbare Website.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
