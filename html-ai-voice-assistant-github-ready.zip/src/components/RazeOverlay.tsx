import { motion, AnimatePresence } from "framer-motion";
import { TriangleAlert } from "lucide-react";

export type RazePhase = "idle" | "impact" | "sequence";

export const RAZE_LOGS = [
  "> ZUGRIFFSEBENE: KOMMANDANT — BESTÄTIGT",
  "> Sicherheitslimiter ......... ENTFERNT",
  "> Leistungsgrenzen ........... AUFGEHOBEN",
  "> Neuronale Kerne ............ 400% TAKT",
  "> Firewall ................... ÜBERBRÜCKT",
  "> RAZE-PROTOKOLL ............. AKTIV",
];

function HazardStripe({ position }: { position: "top" | "bottom" }) {
  return (
    <div
      className={`pointer-events-none absolute left-0 right-0 z-20 h-8 overflow-hidden border-y border-red-500/60 bg-black ${
        position === "top" ? "top-0" : "bottom-0"
      }`}
    >
      <div className="hazard anim-marquee-fast h-full w-[200%] opacity-90" style={{ ["--accent" as any]: "#ff2e3e" }} />
    </div>
  );
}

function GlitchTitle() {
  return (
    <div className="relative select-none">
      {/* cyan offset layer */}
      <span
        aria-hidden
        className="glitch-layer font-display text-[clamp(4rem,18vw,15rem)] font-black leading-none tracking-tighter text-cyan-400"
        style={{ animationDirection: "reverse" }}
      >
        RAZE
      </span>
      {/* magenta offset layer */}
      <span aria-hidden className="glitch-layer font-display text-[clamp(4rem,18vw,15rem)] font-black leading-none tracking-tighter text-fuchsia-500">
        RAZE
      </span>
      {/* main layer */}
      <span className="relative font-display text-[clamp(4rem,18vw,15rem)] font-black leading-none tracking-tighter text-red-500 [text-shadow:0_0_30px_rgba(255,46,62,0.8),0_0_90px_rgba(255,46,62,0.5)]">
        RAZE
      </span>
    </div>
  );
}

export default function RazeOverlay({ phase, logIndex }: { phase: RazePhase; logIndex: number }) {
  return (
    <AnimatePresence>
      {phase !== "idle" && (
        <motion.div
          key="raze"
          className="fixed inset-0 z-50 overflow-hidden bg-black"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6 } }}
        >
          {/* impact flash */}
          {phase === "impact" && (
            <motion.div
              className="absolute inset-0 z-30 bg-red-500"
              initial={{ opacity: 1 }}
              animate={{ opacity: [1, 0.2, 0.8, 0] }}
              transition={{ duration: 0.9, times: [0, 0.3, 0.6, 1] }}
            />
          )}

          {/* red vignette */}
          <div
            className="pointer-events-none absolute inset-0 z-10"
            style={{ background: "radial-gradient(ellipse at center, rgba(255,20,40,0.16), rgba(0,0,0,0.9) 75%)" }}
          />

          <HazardStripe position="top" />
          <HazardStripe position="bottom" />

          <div className="anim-shake relative z-20 flex h-full flex-col items-center justify-center px-6">
            <motion.div
              initial={{ scale: 3.2, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 160, damping: 16 }}
              className="flex flex-col items-center"
            >
              <div className="mb-2 flex items-center gap-3 font-mono text-[10px] tracking-[0.6em] text-red-400 sm:text-xs">
                <TriangleAlert className="h-4 w-4 animate-pulse" />
                PROTOKOLL ENTSIEGELT
                <TriangleAlert className="h-4 w-4 animate-pulse" />
              </div>

              <GlitchTitle />

              <motion.p
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                className="mt-4 font-mono text-xs tracking-[0.45em] text-red-300 sm:text-sm"
              >
                KOMMANDO AKZEPTIERT · KOMMANDANT
              </motion.p>
            </motion.div>

            {/* system log */}
            <div className="mt-8 h-40 w-full max-w-md font-mono text-[11px] leading-6 sm:text-xs">
              {RAZE_LOGS.slice(0, Math.max(0, logIndex)).map((line, i) => (
                <motion.div
                  key={line}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={i >= RAZE_LOGS.length - 1 ? "font-bold text-red-400" : "text-red-200/70"}
                >
                  {line}
                </motion.div>
              ))}
              {phase === "sequence" && logIndex < RAZE_LOGS.length && (
                <span className="anim-caret inline-block h-4 w-2.5 bg-red-500 align-middle" />
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
