import { useEffect, useRef } from "react";

export type CoreState = "idle" | "thinking" | "speaking" | "listening" | "raze";

interface Particle {
  angle: number;
  radius: number;
  speed: number;
  size: number;
  wobble: number;
  wobbleSpeed: number;
}

interface Arc {
  radius: number;
  start: number;
  length: number;
  speed: number;
  width: number;
  alpha: number;
}

export default function AICore({ state, color }: { state: CoreState; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<CoreState>(state);
  const colorRef = useRef(color);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);
  useEffect(() => {
    colorRef.current = color;
  }, [color]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx2d = canvas.getContext("2d");
    if (!ctx2d) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const particles: Particle[] = Array.from({ length: 110 }, () => ({
      angle: Math.random() * Math.PI * 2,
      radius: 0.35 + Math.random() * 1.15,
      speed: (Math.random() * 0.5 + 0.15) * (Math.random() > 0.5 ? 1 : -1),
      size: Math.random() * 2 + 0.6,
      wobble: Math.random() * Math.PI * 2,
      wobbleSpeed: Math.random() * 2 + 0.5,
    }));

    const arcs: Arc[] = [
      { radius: 1.22, start: 0, length: Math.PI * 0.7, speed: 0.35, width: 1.4, alpha: 0.55 },
      { radius: 1.38, start: Math.PI, length: Math.PI * 0.45, speed: -0.5, width: 1, alpha: 0.35 },
      { radius: 1.55, start: Math.PI * 0.5, length: Math.PI * 0.25, speed: 0.22, width: 2, alpha: 0.5 },
      { radius: 1.55, start: Math.PI * 1.4, length: Math.PI * 0.12, speed: 0.22, width: 4, alpha: 0.8 },
    ];

    let t = 0;
    let energy = 0.6;

    const hexToRgb = (hex: string) => {
      const n = parseInt(hex.slice(1), 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    };

    const draw = () => {
      t += 0.016;
      const st = stateRef.current;
      const col = hexToRgb(colorRef.current);
      const colStr = (a: number) => `rgba(${col.r},${col.g},${col.b},${a})`;

      const target =
        st === "thinking" ? 1.15 : st === "speaking" ? 1.5 : st === "listening" ? 1.0 : st === "raze" ? 2.1 : 0.6;
      energy += (target - energy) * 0.05;

      ctx2d.clearRect(0, 0, w, h);
      const cx = w / 2;
      const cy = h / 2;
      const R = Math.min(w, h) * 0.24;

      const speakPulse = st === "speaking" ? 1 + Math.sin(t * 14) * 0.1 + Math.sin(t * 23.7) * 0.06 : 1;
      const razeJitter = st === "raze" ? (Math.random() - 0.5) * 4 : 0;

      // --- Outer glow halo
      const halo = ctx2d.createRadialGradient(cx, cy, 0, cx, cy, R * 2.4);
      halo.addColorStop(0, colStr(0.16 + energy * 0.05));
      halo.addColorStop(0.5, colStr(0.05));
      halo.addColorStop(1, "rgba(0,0,0,0)");
      ctx2d.fillStyle = halo;
      ctx2d.fillRect(0, 0, w, h);

      // --- Rotating arcs
      arcs.forEach((a, i) => {
        a.start += a.speed * 0.016 * (st === "thinking" ? 3.2 : st === "raze" ? 4 : 1) * (st === "speaking" ? 1.8 : 1);
        ctx2d.beginPath();
        ctx2d.strokeStyle = colStr(a.alpha * (st === "raze" ? 0.4 + Math.random() * 0.6 : 1));
        ctx2d.lineWidth = a.width;
        ctx2d.arc(cx + razeJitter, cy + razeJitter, R * a.radius * speakPulse, a.start, a.start + a.length);
        ctx2d.stroke();
        // tick marks on ring i==2
        if (i === 2) {
          for (let k = 0; k < 40; k++) {
            const ang = -a.start * 0.6 + (k / 40) * Math.PI * 2;
            const inner = R * (a.radius - 0.045);
            const outer = R * (a.radius + (k % 5 === 0 ? 0.05 : 0.02));
            ctx2d.beginPath();
            ctx2d.strokeStyle = colStr(k % 5 === 0 ? 0.5 : 0.22);
            ctx2d.lineWidth = 1;
            ctx2d.moveTo(cx + Math.cos(ang) * inner, cy + Math.sin(ang) * inner);
            ctx2d.lineTo(cx + Math.cos(ang) * outer, cy + Math.sin(ang) * outer);
            ctx2d.stroke();
          }
        }
      });

      // --- Orbiting particles
      particles.forEach((p) => {
        p.angle += p.speed * 0.016 * (0.6 + energy * 0.9);
        p.wobble += p.wobbleSpeed * 0.016;
        const wob = Math.sin(p.wobble) * 6;
        const pr = R * p.radius * speakPulse + wob;
        let x = cx + Math.cos(p.angle) * pr;
        let y = cy + Math.sin(p.angle) * pr * 0.92; // slight ellipse
        if (st === "raze") {
          x += (Math.random() - 0.5) * 3;
          y += (Math.random() - 0.5) * 3;
        }
        const alpha = (p.radius < 0.9 ? 0.85 : 0.4) * (0.5 + energy * 0.35);
        ctx2d.beginPath();
        ctx2d.fillStyle = colStr(alpha);
        ctx2d.arc(x, y, p.size * (0.7 + energy * 0.35), 0, Math.PI * 2);
        ctx2d.fill();
      });

      // --- Core sphere
      const coreR = R * 0.62 * speakPulse * (1 + energy * 0.06);
      const core = ctx2d.createRadialGradient(cx - coreR * 0.3, cy - coreR * 0.3, 0, cx, cy, coreR);
      core.addColorStop(0, "rgba(255,255,255,0.9)");
      core.addColorStop(0.25, colStr(0.85));
      core.addColorStop(0.7, colStr(0.25));
      core.addColorStop(1, "rgba(0,0,0,0)");
      ctx2d.beginPath();
      ctx2d.fillStyle = core;
      ctx2d.arc(cx + razeJitter * 0.5, cy + razeJitter * 0.5, coreR, 0, Math.PI * 2);
      ctx2d.fill();

      // --- Inner bright nucleus
      const nuc = 3 + energy * 3 + (st === "speaking" ? Math.sin(t * 20) * 1.6 : 0);
      ctx2d.beginPath();
      ctx2d.fillStyle = "rgba(255,255,255,0.95)";
      ctx2d.arc(cx, cy, Math.max(nuc, 2), 0, Math.PI * 2);
      ctx2d.fill();

      // --- Concentric breathing ring
      const breath = R * (0.82 + Math.sin(t * (st === "raze" ? 8 : 1.6)) * 0.03);
      ctx2d.beginPath();
      ctx2d.strokeStyle = colStr(0.35);
      ctx2d.lineWidth = 1;
      ctx2d.arc(cx, cy, breath, 0, Math.PI * 2);
      ctx2d.stroke();

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return <canvas ref={canvasRef} className="h-full w-full" aria-label="NEXA Kern-Visualisierung" />;
}
