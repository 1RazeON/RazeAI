# HTML AI Voice Assistant

## Installation
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
